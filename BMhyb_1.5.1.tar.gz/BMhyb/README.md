[![Build Status](https://travis-ci.org/bomeara/BMhyb.svg)](https://travis-ci.org/bomeara/BMhyb)

This is a package for doing comparative methods on networks. It's been in peer review twice but not accepted, and the current version has a fatal flaw. So don't use it.

To install it (but see caveat above):

```
install.packages("BMhyb")
devtools::install_github("bomeara/BMhyb")
```
