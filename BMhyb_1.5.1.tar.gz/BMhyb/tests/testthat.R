library(testthat)
test_check("BMhyb")
